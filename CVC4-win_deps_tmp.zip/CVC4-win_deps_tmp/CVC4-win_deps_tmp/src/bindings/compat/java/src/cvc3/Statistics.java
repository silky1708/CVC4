package cvc3;

import java.util.*;

public class Statistics extends Embedded {
    // jni methods

    /// Constructor

    public Statistics(Object Statistics, EmbeddedManager embeddedManager) {
	super(Statistics, embeddedManager);
    }


    /// API (immutable)

}
