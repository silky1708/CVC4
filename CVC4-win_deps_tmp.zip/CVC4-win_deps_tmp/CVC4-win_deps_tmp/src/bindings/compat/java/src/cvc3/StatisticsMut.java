package cvc3;

import java.util.*;

public class StatisticsMut extends Statistics {
    // jni methods
    
    
    /// Constructor

    // create embedded object
    public StatisticsMut(Object StatisticsMut, EmbeddedManager embeddedManager) {
	super(StatisticsMut, embeddedManager);
    }

    
    /// API (mutable)
}
