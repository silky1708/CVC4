#include "cvc4_private.h"

#ifndef __CVC4__THEORY__$id__OPTIONS_HANDLERS_H
#define __CVC4__THEORY__$id__OPTIONS_HANDLERS_H

namespace CVC4 {
namespace theory {
namespace $dir {

}/* CVC4::theory::$dir namespace */
}/* CVC4::theory namespace */
}/* CVC4 namespace */

#endif /* __CVC4__THEORY__$id__OPTIONS_HANDLERS_H */
